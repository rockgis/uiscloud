"use strict";

var app = angular.module('draw2dApp', ["draw2d", 'ui.bootstrap']);
